const express = require("express");
const db = require("../db");

const router = express.Router();

// Mark Attendance
router.post("/mark-attendance", (req, res) => {
  const { studentId, classId, date, status } = req.body;
  const sql = "INSERT INTO attendance (student_id, class_id, date, status) VALUES (?, ?, ?, ?)";

  db.query(sql, [studentId, classId, date, status], (err, result) => {
    if (err) return res.status(500).json(err);
    res.json({ message: "Attendance marked successfully" });
  });
});

module.exports = router;
