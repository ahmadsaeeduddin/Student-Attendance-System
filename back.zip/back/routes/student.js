const express = require("express");
const db = require("../db");

const router = express.Router();

// Get Attendance History for Student
router.get("/attendance/:studentId", (req, res) => {
  const { studentId } = req.params;
  const sql = `SELECT * FROM attendance WHERE student_id = ?`;

  db.query(sql, [studentId], (err, results) => {
    if (err) return res.status(500).json(err);
    res.json(results);
  });
});

module.exports = router;
