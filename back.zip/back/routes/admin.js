const express = require("express");
const db = require("../db");

const router = express.Router();

// Get Total Students
router.get("/students", (req, res) => {
  const sql = "SELECT COUNT(*) AS total FROM students";

  db.query(sql, (err, results) => {
    if (err) return res.status(500).json(err);
    res.json(results[0]);
  });
});

module.exports = router;
