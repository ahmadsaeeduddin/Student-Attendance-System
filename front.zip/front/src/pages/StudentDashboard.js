import React, { useState } from "react";
import { Link } from "react-router-dom";
import styles from "../styles/StudentDashboard.module.css"; // Import CSS Module

const StudentDashboard = () => {
  const classes = ["Computer Science", "Mathematics", "Physics"];

  const attendanceData = {
    "Computer Science": [
      { date: "2024-03-01", status: "Present" },
      { date: "2024-03-02", status: "Absent" },
      { date: "2024-03-03", status: "Late" },
    ],
    Mathematics: [
      { date: "2024-03-01", status: "Present" },
      { date: "2024-03-02", status: "Present" },
      { date: "2024-03-03", status: "Absent" },
    ],
    Physics: [
      { date: "2024-03-01", status: "Late" },
      { date: "2024-03-02", status: "Present" },
      { date: "2024-03-03", status: "Present" },
    ],
  };

  const [selectedClass, setSelectedClass] = useState("");
  const [attendanceHistory, setAttendanceHistory] = useState([]);
  const [attendancePercentage, setAttendancePercentage] = useState(0);
  const [lowAttendanceWarning, setLowAttendanceWarning] = useState(false);

  const handleClassChange = (e) => {
    const className = e.target.value;
    setSelectedClass(className);

    if (className && attendanceData[className]) {
      setAttendanceHistory(attendanceData[className]);
      calculateAttendancePercentage(attendanceData[className]);
    } else {
      setAttendanceHistory([]);
      setAttendancePercentage(0);
    }
  };

  const calculateAttendancePercentage = (records) => {
    const totalDays = records.length;
    const presentDays = records.filter((record) => record.status === "Present").length;
    const percentage = totalDays > 0 ? (presentDays / totalDays) * 100 : 0;

    setAttendancePercentage(percentage.toFixed(2));
    setLowAttendanceWarning(percentage < 75);
  };

  const downloadAttendance = () => {
    if (!selectedClass) {
      alert("Please select a class first.");
      return;
    }

    let csvContent = "Date,Status\n";
    attendanceHistory.forEach((record) => {
      csvContent += `${record.date},${record.status}\n`;
    });

    const blob = new Blob([csvContent], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${selectedClass}_Attendance.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  return (
    <div className={styles.studentDashboard}>
      <nav className={styles.sidebar}>
        <h2>Student Panel</h2>
        <ul>
          <li>
            <Link onClick={() => setSelectedClass("")}>Dashboard</Link>
          </li>
          <li>
            <a href="/">Logout</a>
          </li>
        </ul>
      </nav>

      <main className={styles.dashboardContent}>
        <h1>Student Dashboard</h1>

        <h2>View Attendance History</h2>
        <select className={styles.classSelect} onChange={handleClassChange} value={selectedClass}>
          <option value="">-- Select a Class --</option>
          {classes.map((cls, index) => (
            <option key={index} value={cls}>
              {cls}
            </option>
          ))}
        </select>

        {selectedClass && attendanceHistory.length > 0 && (
          <>
            <h3>Attendance for {selectedClass}</h3>
            <table>
              <thead>
                <tr>
                  <th>Date</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {attendanceHistory.map((record, index) => (
                  <tr key={index}>
                    <td>{record.date}</td>
                    <td className={styles[record.status.toLowerCase()]}>{record.status}</td>
                  </tr>
                ))}
              </tbody>
            </table>

            <h3>Overall Attendance: {attendancePercentage}%</h3>
            {lowAttendanceWarning && (
              <p className={styles.warning}>
                ⚠️ Your attendance is below 75%! Please improve it.
              </p>
            )}

            <button className={styles.downloadBtn} onClick={downloadAttendance}>
              Download Attendance
            </button>
          </>
        )}
      </main>
    </div>
  );
};

export default StudentDashboard;
