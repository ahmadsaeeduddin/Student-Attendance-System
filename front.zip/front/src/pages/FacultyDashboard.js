import React, { useState } from "react";
import { Link } from "react-router-dom";
import styles from "../styles/FacultyDashboard.module.css"; // Import CSS Module

const FacultyDashboard = () => {
  const classes = ["Computer Science", "Mathematics", "Physics"];
  const studentsData = {
    "Computer Science": [
      { id: 1, name: "John Doe", status: "Absent" },
      { id: 2, name: "Jane Smith", status: "Absent" },
    ],
    Mathematics: [
      { id: 3, name: "Mike Johnson", status: "Absent" },
      { id: 4, name: "Emily Davis", status: "Absent" },
    ],
    Physics: [
      { id: 5, name: "Robert Brown", status: "Absent" },
      { id: 6, name: "Sophia Wilson", status: "Absent" },
    ],
  };

  const [selectedClass, setSelectedClass] = useState("");
  const [selectedDate, setSelectedDate] = useState("");
  const [students, setStudents] = useState([]);
  const [attendanceRecords, setAttendanceRecords] = useState({});
  const [activeSection, setActiveSection] = useState("mark");

  const handleClassChange = (e) => {
    const selected = e.target.value;
    setSelectedClass(selected);
  
    // Load students for the selected class into state
    setStudents(studentsData[selected] ? [...studentsData[selected]] : []);
  };
  
  

  const handleDateChange = (e) => {
    setSelectedDate(e.target.value);
  };

  const changeAttendanceStatus = (index, status) => {
    setStudents((prevStudents) => {
      const updatedStudents = [...prevStudents];
      updatedStudents[index] = { ...updatedStudents[index], status };
      return updatedStudents;
    });
  };
  
  

  const submitAttendance = () => {
    if (!selectedClass || !selectedDate) {
      alert("Please select a class and date.");
      return;
    }
  
    setAttendanceRecords((prevRecords) => ({
      ...prevRecords,
      [selectedDate]: { 
        ...prevRecords[selectedDate], 
        [selectedClass]: [...students] // Store updated students
      },
    }));
  
    alert("Attendance submitted successfully!");
  };
  

  const viewAttendance = () => {
    if (!selectedDate || !selectedClass) {
      alert("Please select both a class and date.");
      return;
    }
    if (!attendanceRecords[selectedDate] || !attendanceRecords[selectedDate][selectedClass]) {
      alert("No records found for this class on the selected date.");
      return;
    }
    setStudents(attendanceRecords[selectedDate][selectedClass] || []);
  };

  return (
    <div className={styles.facultyDashboard}>
      <nav className={styles.sidebar}>
        <h2>Faculty Panel</h2>
        <ul>
          <li><Link onClick={() => setActiveSection("mark")}>Mark Attendance</Link></li>
          <li><Link onClick={() => setActiveSection("edit")}>Edit Attendance</Link></li>
          <li><Link onClick={() => setActiveSection("view")}>View Attendance</Link></li>
          <li>
            <a href="/">Logout</a>
          </li>
        </ul>
      </nav>

      <main className={styles.dashboardContent}>
        <h1>Faculty Dashboard</h1>

        {activeSection === "mark" && (
          <>
            <h2>Mark Attendance</h2>
            <div className={styles.selectionContainer}>
              <select className={styles.classSelect} onChange={handleClassChange} value={selectedClass}>
                <option value="">-- Select a Class --</option>
                {classes.map((cls, index) => (
                  <option key={index} value={cls}>{cls}</option>
                ))}
              </select>

              <input type="date" className={styles.datePicker} onChange={handleDateChange} value={selectedDate} />
            </div>

            {selectedClass && selectedDate && (
              <>
                <h3>Mark Attendance for {selectedClass} on {selectedDate}</h3>
                <table>
                  <thead>
                    <tr>
                      <th>ID</th>
                      <th>Name</th>
                      <th>Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {students.map((student, index) => (
                      <tr key={student.id}>
                        <td>{student.id}</td>
                        <td>{student.name}</td>
                        <td>
                          <select
                            value={student.status}
                            onChange={(e) => changeAttendanceStatus(index, e.target.value)}
                          >
                            <option value="Present">Present</option>
                            <option value="Absent">Absent</option>
                            <option value="Late">Late</option>
                          </select>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                <button className={styles.markBtn} onClick={submitAttendance}>Submit Attendance</button>
              </>
            )}
          </>
        )}

        {activeSection === "edit" && (
          <>
            <h2>Edit Attendance</h2>
            <p>Coming soon... (Will allow modifying attendance records)</p>
          </>
        )}

        {activeSection === "view" && (
          <>
            <h2>View Attendance</h2>
            <div className={styles.selectionContainer}>
              <select className={styles.classSelect} onChange={handleClassChange} value={selectedClass}>
                <option value="">-- Select a Class --</option>
                {classes.map((cls, index) => (
                  <option key={index} value={cls}>{cls}</option>
                ))}
              </select>

              <input type="date" className={styles.datePicker} onChange={handleDateChange} value={selectedDate} />
            </div>

            <button className={styles.viewBtn} onClick={viewAttendance}>View Attendance</button>

            {students.length > 0 && (
              <>
                <h3>Attendance Records for {selectedClass} on {selectedDate}</h3>
                <table>
                  <thead>
                    <tr>
                      <th>ID</th>
                      <th>Name</th>
                      <th>Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {students.map((student) => (
                      <tr key={student.id}>
                        <td>{student.id}</td>
                        <td>{student.name}</td>
                        <td>{student.status}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </>
            )}
          </>
        )}
      </main>
    </div>
  );
};

export default FacultyDashboard;
