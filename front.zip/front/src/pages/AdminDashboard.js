import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import axios from "axios"; // Import Axios for API calls
import styles from "../styles/AdminDashboard.module.css";

const AdminDashboard = () => {
  const [activeSection, setActiveSection] = useState("dashboard");

  // Store students & faculty from the database
  const [students, setStudents] = useState([]);
  const [faculty, setFaculty] = useState([]);

  // State for new student & faculty
  const [newStudent, setNewStudent] = useState({ name: "", email: "", password: "", department: "" });
  const [newFaculty, setNewFaculty] = useState({ name: "", email: "", password: "", subject: "" });

  // Fetch students and faculty from the backend
  useEffect(() => {
    fetchStudents();
    fetchFaculty();
  }, []);

  const fetchStudents = async () => {
    try {
      const res = await axios.get("http://localhost:5000/api/students");
      setStudents(res.data);
    } catch (error) {
      console.error("Error fetching students:", error);
    }
  };

  const fetchFaculty = async () => {
    try {
      const res = await axios.get("http://localhost:5000/api/faculty");
      setFaculty(res.data);
    } catch (error) {
      console.error("Error fetching faculty:", error);
    }
  };

  // Handle input changes
  const handleStudentChange = (e) => setNewStudent({ ...newStudent, [e.target.name]: e.target.value });
  const handleFacultyChange = (e) => setNewFaculty({ ...newFaculty, [e.target.name]: e.target.value });

  // Add Student
  const addStudent = async () => {
    if (!newStudent.name || !newStudent.email || !newStudent.password || !newStudent.department) return;
    try {
      await axios.post("http://localhost:5000/api/students", newStudent);
      fetchStudents(); // Refresh list after adding
      setNewStudent({ name: "", email: "", password: "", department: "" });
    } catch (error) {
      console.error("Error adding student:", error);
    }
  };

  // Add Faculty
  const addFaculty = async () => {
    if (!newFaculty.name || !newFaculty.email || !newFaculty.password || !newFaculty.subject) return;
    try {
      await axios.post("http://localhost:5000/api/faculty", newFaculty);
      fetchFaculty(); // Refresh list after adding
      setNewFaculty({ name: "", email: "", password: "", subject: "" });
    } catch (error) {
      console.error("Error adding faculty:", error);
    }
  };

  // Delete Student
  const deleteStudent = async (id) => {
    try {
      await axios.delete(`http://localhost:5000/api/students/${id}`);
      fetchStudents(); // Refresh list after deleting
    } catch (error) {
      console.error("Error deleting student:", error);
    }
  };

  // Delete Faculty
  const deleteFaculty = async (id) => {
    try {
      await axios.delete(`http://localhost:5000/api/faculty/${id}`);
      fetchFaculty(); // Refresh list after deleting
    } catch (error) {
      console.error("Error deleting faculty:", error);
    }
  };

  return (
    <div className={styles.adminDashboard}>
      {/* Sidebar */}
      <nav className={styles.sidebar}>
        <h2>Admin Panel</h2>
        <ul>
          <li> <Link onClick={() => setActiveSection("dashboard")}>Dashboard</Link></li>
          <li> <Link onClick={() => setActiveSection("manageStudents")}>Manage Students</Link></li>
          <li> <Link onClick={() => setActiveSection("manageFaculty")}>Manage Faculty</Link></li>
          <li><Link to="/">Logout</Link></li>
        </ul>
      </nav>

      {/* Main Content */}
      <main className={styles.dashboardContent}>
        {activeSection === "dashboard" && (
          <>
            <h1>Admin Dashboard</h1>
            <div className={styles.dashboardCards}>
              <div className={styles.card}>
                <h3>Total Students</h3>
                <p>{students.length}</p>
              </div>
              <div className={styles.card}>
                <h3>Total Faculty</h3>
                <p>{faculty.length}</p>
              </div>
              <div className={styles.card}>
                <h3>Attendance Reports</h3>
                <p>View Detailed Reports</p>
              </div>
            </div>
          </>
        )}

        {/* Manage Students Section */}
        {activeSection === "manageStudents" && (
          <>
            <h2>Manage Students</h2>
            <div className={styles.inputContainer}>
              <input type="text" name="name" placeholder="Student Name" value={newStudent.name} onChange={handleStudentChange} />
              <input type="email" name="email" placeholder="Email" value={newStudent.email} onChange={handleStudentChange} />
              <input type="password" name="password" placeholder="Password" value={newStudent.password} onChange={handleStudentChange} />
              <input type="text" name="department" placeholder="Department" value={newStudent.department} onChange={handleStudentChange} />
              <button onClick={addStudent} className={styles.addButton}>Add Student</button>
            </div>

            <table>
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Department</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {students.map((student) => (
                  <tr key={student.id}>
                    <td>{student.id}</td>
                    <td>{student.name}</td>
                    <td>{student.email}</td>
                    <td>{student.department}</td>
                    <td>
                      <button className={styles.deleteButton} onClick={() => deleteStudent(student.id)}>Delete</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </>
        )}

        {/* Manage Faculty Section */}
        {activeSection === "manageFaculty" && (
          <>
            <h2>Manage Faculty</h2>
            <div className={styles.inputContainer}>
              <input type="text" name="name" placeholder="Faculty Name" value={newFaculty.name} onChange={handleFacultyChange} />
              <input type="email" name="email" placeholder="Email" value={newFaculty.email} onChange={handleFacultyChange} />
              <input type="password" name="password" placeholder="Password" value={newFaculty.password} onChange={handleFacultyChange} />
              <input type="text" name="subject" placeholder="Subject" value={newFaculty.subject} onChange={handleFacultyChange} />
              <button onClick={addFaculty} className={styles.addButton}>Add Faculty</button>
            </div>

            <table>
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Subject</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {faculty.map((faculty) => (
                  <tr key={faculty.id}>
                    <td>{faculty.id}</td>
                    <td>{faculty.name}</td>
                    <td>{faculty.email}</td>
                    <td>{faculty.subject}</td>
                    <td>
                      <button className={styles.deleteButton} onClick={() => deleteFaculty(faculty.id)}>Delete</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </>
        )}
      </main>
    </div>
  );
};

export default AdminDashboard;
